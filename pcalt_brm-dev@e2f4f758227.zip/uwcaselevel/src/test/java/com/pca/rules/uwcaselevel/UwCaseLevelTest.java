package com.pca.rules.uwcaselevel;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

public class UwCaseLevelTest {

  protected static String KIE_BASE_NAME = "kbase-uwcaselevel";
  protected static String KIE_SESSION_NAME = "defaultKieSession";

  private final static String OUTIDENTIFIER = "outIdentifier";


  protected static KieBase kieBase = null;
  protected static KieServices ks = KieServices.Factory.get();
  protected static KieContainer kieContainer = ks.newKieClasspathContainer();
  protected static KieCommands kieCommands = ks.getCommands();


  @Before
  public void prepareKieBase() {
    if (KIE_BASE_NAME == null || KIE_BASE_NAME.length() == 0) {
      kieBase = kieContainer.getKieBase();
    } else {
      kieBase = kieContainer.getKieBase(KIE_BASE_NAME);
    }
  }


  @Test
  public void uwCaseLeveltest() throws Exception {

    List<Policy> policyList = new ArrayList<Policy>();
    
    Policy policy = new Policy();
    policy.setId("test1");
    policy.setAccType("01");
    policy.setInstprem(7000000d);
    policy.setSumins(70000000d);
    policy.setPhyexmult(0.6d);
    policy.setLifemult(0.5d);
	policyList.add(policy);
	
	Policy policy1 = new Policy();
	policy1.setId("test1");
    policy1.setAccType("02");
    policy1.setInstprem(100d);
    policy1.setSumins(100d);
    policy1.setPhyexmult(1d);
    policy1.setLifemult(1d);
	policyList.add(policy1);
	
	Policy policy2 = new Policy();
	policy2.setId("test1");
    policy2.setAccType("03");
    policy2.setInstprem(1000d);
    policy2.setSumins(1000d);
    policy2.setPhyexmult(0.6d);
    policy2.setLifemult(0.5d);
	policyList.add(policy2);
	
	Policy policy3 = new Policy();
	policy3.setId("test2");
    policy3.setAccType("01");
    policy3.setInstprem(3000d);
    policy3.setSumins(3000d);
    policy3.setPhyexmult(0.6d);
    policy3.setLifemult(0.5d);
	policyList.add(policy3);

	Policy policy4 = new Policy();
    policy4.setId("test1");
    policy4.setAccType("11");
    policy4.setInstprem(500d);
    policy4.setSumins(500d);
    policy4.setPhyexmult(0.6d);
    policy4.setLifemult(0.5d);
	policyList.add(policy4);
	
	Policy policy5 = new Policy();
	policy5.setId("test3");
    policy5.setAccType("01");
    policy5.setInstprem(2000d);
    policy5.setSumins(2000d);
    policy5.setPhyexmult(0.6d);
    policy5.setLifemult(0.5d);
	policyList.add(policy5);
	
	// 執行派工決策表
    UwResult resultTask = runWithSinglePcaTask(policyList);
    //System.out.println(resultTask);

  }


  // This test run will always run with 取件模式 = DATA_ENTRY
  protected UwResult runWithSinglePcaTask(List<Policy> policyList) {
    KieServices ks = KieServices.Factory.get();
    StatelessKieSession kieSession =
        ks.getKieClasspathContainer().newStatelessKieSession(KIE_SESSION_NAME);


    @SuppressWarnings("rawtypes")
    List<Command> cmds = new ArrayList<Command>();
    for(Policy policy : policyList){
    	cmds.add(kieCommands.newInsert(policy));
    }
    cmds.add(kieCommands.newInsert(new UwResult()));
    cmds.add(kieCommands.newFireAllRules());
    cmds.add(kieCommands.newQuery(OUTIDENTIFIER, "get max case level"));
    ExecutionResults results = kieSession.execute(kieCommands.newBatchExecution(cmds));

    // returns the query as a QueryResults instance.
    QueryResults qrs = (QueryResults) results.getValue(OUTIDENTIFIER);
    UwResult resultTask = null;
	// Here, we only return 1st result
	if (qrs.iterator().hasNext()) {
		for (QueryResultsRow qr : qrs) {
//			resultTask = (UwResult) qr.get("$result");
//			System.out.println("resultTask: " + resultTask.toString());
			Double uwCaseLevel = (Double) qr.get("$uwCaseLevel");
			System.out.println("uwCaseLevel: " + uwCaseLevel.intValue());
		}

	}
    
    return resultTask;
  }

}
