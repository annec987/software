package com.pca.rules.uwcaselevel;

public class UwResult {
	
	private String id;
	private String uwType;  /* 個人壽險..  */
	private double totale;
	private int uwLevel;  /* 1-實習審核人員.. */
	private String uwLevelName;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUwType() {
		return uwType;
	}

	public void setUwType(String uwType) {
		this.uwType = uwType;
	}

	public double getTotale() {
		return totale;
	}

	public void setTotale(double totale) {
		this.totale = totale;
	}

	public int getUwLevel() {
		return uwLevel;
	}

	public void setUwLevel(int uwLevel) {
		this.uwLevel = uwLevel;
	}

	public String getUwLevelName() {
		return uwLevelName;
	}

	public void setUwLevelName(String uwLevelName) {
		this.uwLevelName = uwLevelName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UwResult [id=");
		builder.append(id);
		builder.append(", uwType=");
		builder.append(uwType);
		builder.append(", totale=");
		builder.append(totale);
		builder.append(", uwLevel=");
		builder.append(uwLevel);
		builder.append(", uwLevelName=");
		builder.append(uwLevelName);
		builder.append("]");
		return builder.toString();
	}

}
