package com.pca.rules.uwcaselevel;

public class Policy {
	private String id;
	private String accType;
	private double sumins;
	private double phyexmult;
	private double lifemult;
	private double instprem;
	private Boolean accUsed = Boolean.FALSE;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getSumins() {
		return sumins;
	}

	public void setSumins(double sumins) {
		this.sumins = sumins;
	}

	public double getPhyexmult() {
		return phyexmult;
	}

	public void setPhyexmult(double phyexmult) {
		this.phyexmult = phyexmult;
	}

	public double getLifemult() {
		return lifemult;
	}

	public void setLifemult(double lifemult) {
		this.lifemult = lifemult;
	}

	public double getInstprem() {
		return instprem;
	}

	public void setInstprem(double instprem) {
		this.instprem = instprem;
	}

	public Boolean getAccUsed() {
		return accUsed;
	}

	public void setAccUsed(Boolean accUsed) {
		this.accUsed = accUsed;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Policy [id=");
		builder.append(id);
		builder.append(", accType=");
		builder.append(accType);
		builder.append(", sumins=");
		builder.append(sumins);
		builder.append(", phyexmult=");
		builder.append(phyexmult);
		builder.append(", lifemult=");
		builder.append(lifemult);
		builder.append(", instprem=");
		builder.append(instprem);
		builder.append(", accUsed=");
		builder.append(accUsed);
		builder.append("]");
		return builder.toString();
	}

}
