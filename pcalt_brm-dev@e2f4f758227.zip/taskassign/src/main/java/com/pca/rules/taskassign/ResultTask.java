package com.pca.rules.taskassign;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@org.kie.api.remote.Remotable
public class ResultTask implements Serializable, Comparable
{

   /**
    *
    */
   private static final long serialVersionUID = 2702086578567192854L;

   // Task ID
   private long id;
   // 任務種類
   private String pcaTaskType;
   // 利用者可認領
   private Boolean isClaimable;
   // 任務優先度(符合指定條件)
   private long scoreSpecialCondition;
   // 任務優先度(使用者工作優先比分)
   private long scoreUserTaskPriority;
   // 任務優先度(案件重要性比分)
   private long scoreCaseImportance;
   // 任務優先度(保單審核優先比分)
   private long scoreUnderwriting;
   // 任務優先度(建立時間優先比分)
   private long scoreTriggerTime;
   // 任務優先度(總比分)
   private long totalScore;
   // 系統處理履歷
   private List<String> logs;

   public ResultTask()
   {
      // Initialize result task as claimable
      this.isClaimable = true;
      // Initialize logs
      logs = new ArrayList<String>();
   }

   /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
   @Override
   public String toString()
   {
      return "ResultTask [id=" + id + ", " + (pcaTaskType != null ? "pcaTaskType=" + pcaTaskType + ", " : "")
            + (isClaimable != null ? "isClaimable=" + isClaimable + ", " : "")
            + ("scoreSpecialCondition=" + scoreSpecialCondition + ", ")
            + "scoreUserTaskPriority=" + scoreUserTaskPriority
            + ", scoreCaseImportance=" + scoreCaseImportance
            + ", scoreUnderwriting=" + scoreUnderwriting + ", "
            + ", scoreTriggerTime=" + scoreTriggerTime + ", "
            + ", totalScore=" + totalScore + " ]";
   }

   /**
    * @return the id
    */
   public long getId()
   {
      return id;
   }

   /**
    * @param id the id to set
    */
   public void setId(long id)
   {
      this.id = id;
   }

   /**
    * @return the pcaTaskType
    */
   public String getPcaTaskType()
   {
      return pcaTaskType;
   }

   /**
    * @param pcaTaskType the pcaTaskType to set
    */
   public void setPcaTaskType(String pcaTaskType)
   {
      this.pcaTaskType = pcaTaskType;
   }

   /**
    * @return the isClaimable
    */
   public Boolean getIsClaimable()
   {
      return isClaimable;
   }

   /**
    * @param isClaimable the isClaimable to set
    */
   public void setIsClaimable(Boolean isClaimable)
   {
//      this.isClaimable = this.isClaimable && isClaimable;
      this.isClaimable = isClaimable;
   }

   /**
    * @return the scoreSpecialCondition
    */
   public long getScoreSpecialCondition()
   {
      return this.scoreSpecialCondition;
   }

   /**
    * @param isSpecialCondition the isSpecialCondition to set
    */
   public void setScoreSpecialCondition(long scoreSpecialCondition)
   {
      this.scoreSpecialCondition = scoreSpecialCondition;
   }

   /**
    * @return the scoreUserTaskPriority
    */
   public long getScoreUserTaskPriority()
   {
      return scoreUserTaskPriority;
   }

   /**
    * @param scoreUserTaskPriority the scoreUserTaskPriority to set
    */
   public void setScoreUserTaskPriority(long scoreUserTaskPriority)
   {
      this.scoreUserTaskPriority = scoreUserTaskPriority;
   }

   /**
    * @return the scoreCaseImportance
    */
   public long getScoreCaseImportance()
   {
      return scoreCaseImportance;
   }

   /**
    * @param scoreCaseImportance the scoreCaseImportance to set
    */
   public void setScoreCaseImportance(long scoreCaseImportance)
   {
      this.scoreCaseImportance = scoreCaseImportance;
   }

   /**
    * @return the scoreUnderwriting
    */
   public long getScoreUnderwriting()
   {
      return scoreUnderwriting;
   }

   /**
    * @param scoreUnderwriting the scoreUnderwriting to set
    */
   public void setScoreUnderwriting(long scoreUnderwriting)
   {
      this.scoreUnderwriting = scoreUnderwriting;
   }

   /**
    * @return the scoreTriggerTime
    */
   public long getScoreTriggerTime()
   {
      return scoreTriggerTime;
   }

   /**
    * @param scoreTriggerTime the scoreTriggerTime to set
    */
   public void setScoreTriggerTime(long scoreTriggerTime)
   {
      this.scoreTriggerTime = scoreTriggerTime;
   }

   /**
    * @return the scoreTotal
    */
   public long getTotalScore()
   {
      return totalScore;
   }

   /**
    * @param scoreTotal the scoreTotal to set
    */
   public void setTotalScore(long totalScore)
   {
      this.totalScore = totalScore;
   }

   /**
    * @return the logs
    */
   public List<String> getLogs()
   {
      return logs;
   }

   /**
    * @param ruleId Rule Name in Decision Table
    * @param msg Message to log
    */
   public void addLog(String ruleId, String msg)
   {
      DateFormat dateFormat = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss.SSS");
      Date date = new Date();
      String log = dateFormat.format(date) + " [" + ruleId + "] " + msg;
      System.out.println(log);
      logs.add(log);
   }

   public int compareTo(Object o)
   {
      Long thisScore = Long.valueOf(this.totalScore);
      Long otherScore = Long.valueOf(((ResultTask) o).getTotalScore());
      return thisScore.compareTo(otherScore);
   }

   public ResultTask(long id, java.lang.String pcaTaskType,
         java.lang.Boolean isClaimable, long scoreSpecialCondition,
         long scoreUserTaskPriority, long scoreCaseImportance,
         long scoreUnderwriting, long scoreTriggerTime, long totalScore,
         java.util.List<java.lang.String> logs)
   {
      this.id = id;
      this.pcaTaskType = pcaTaskType;
      this.isClaimable = isClaimable;
      this.scoreSpecialCondition = scoreSpecialCondition;
      this.scoreUserTaskPriority = scoreUserTaskPriority;
      this.scoreCaseImportance = scoreCaseImportance;
      this.scoreUnderwriting = scoreUnderwriting;
      this.scoreTriggerTime = scoreTriggerTime;
      this.totalScore = totalScore;
      this.logs = logs;
   }

}
