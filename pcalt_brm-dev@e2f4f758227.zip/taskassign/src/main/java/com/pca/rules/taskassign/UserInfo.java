package com.pca.rules.taskassign;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@org.kie.api.remote.Remotable
public class UserInfo implements Serializable
{

   /**
    *
    */
   private static final long serialVersionUID = 2919355656009879162L;

   // User ID
   private java.lang.String userId;

   // User Name
   private java.lang.String userName;

   // 用戶角色
   private java.util.List<java.lang.String> roles;

   // 保單審核等級
   private int underwritingLevel;

   // 保單審核金額下限
   private java.math.BigDecimal underwritingPriceFrom;

   // 保單審核金額上限
   private java.math.BigDecimal underwritingPriceTo;

   public UserInfo()
   {
   }

   public UserInfo(String userId, String userName, List<String> roles, BigDecimal underwritingPriceFrom,
         BigDecimal underwritingPriceTo, int underwritingLevel)
   {
      super();
      this.userId = userId;
      this.userName = userName;
      this.roles = roles;
      this.underwritingPriceFrom = underwritingPriceFrom;
      this.underwritingPriceTo = underwritingPriceTo;
      this.underwritingLevel = underwritingLevel;
   }

   /**
    * @return the roles
    */
   public java.util.List<java.lang.String> getRoles()
   {
      return roles;
   }

   /**
    * @return the underwriting_level
    */
   public int getUnderwritingLevel()
   {
      return underwritingLevel;
   }

   /**
    * @return the underwriting_price_from
    */
   public java.math.BigDecimal getUnderwritingPriceFrom()
   {
      return underwritingPriceFrom;
   }

   /**
    * @return the underwritingPriceTo
    */
   public java.math.BigDecimal getUnderwritingPriceTo()
   {
      return underwritingPriceTo;
   }

   /**
    * @return the userId
    */
   public java.lang.String getUserId()
   {
      return userId;
   }

   /**
    * @return the userName
    */
   public java.lang.String getUserName()
   {
      return userName;
   }

   /**
    * @param roles
    *            the roles to set
    */
   public void setRoles(java.util.List<java.lang.String> roles)
   {
      this.roles = roles;
   }

   /**
    * @param underwriting_level
    *            the underwriting_level to set
    */
   public void setUnderwritingLevel(int underwritingLevel)
   {
      this.underwritingLevel = underwritingLevel;
   }

   /**
    * @param underwriting_price_from
    *            the underwriting_price_from to set
    */
   public void setUnderwritingPriceFrom(java.math.BigDecimal underwritingPriceFrom)
   {
      this.underwritingPriceFrom = underwritingPriceFrom;
   }

   /**
    * @param underwritingPriceTo
    *            the underwritingPriceTo to set
    */
   public void setUnderwritingPriceTo(java.math.BigDecimal underwritingPriceTo)
   {
      this.underwritingPriceTo = underwritingPriceTo;
   }

   /**
    * @param userId
    *            the userId to set
    */
   public void setUserId(java.lang.String userId)
   {
      this.userId = userId;
   }

   /**
    * @param userName
    *            the userName to set
    */
   public void setUserName(java.lang.String userName)
   {
      this.userName = userName;
   }

   /*
    * (non-Javadoc)
    *
    * @see java.lang.Object#toString()
    */
   @Override
   public String toString()
   {
      return "UserInfo [" + (userId != null ? "userId=" + userId + ", " : "")
            + (userName != null ? "userName=" + userName + ", " : "")
            + (roles != null ? "roles=" + roles + ", " : "")
            + (underwritingPriceFrom != null ? "underwritingPriceFrom=" + underwritingPriceFrom + ", " : "")
            + (underwritingPriceTo != null ? "underwritingPriceTo=" + underwritingPriceTo + ", " : "")
            + ("underwritingLevel=" + underwritingLevel) + "]";
   }

   public UserInfo(java.lang.String userId, java.lang.String userName,
         java.util.List<java.lang.String> roles, int underwritingLevel,
         java.math.BigDecimal underwritingPriceFrom,
         java.math.BigDecimal underwritingPriceTo)
   {
      this.userId = userId;
      this.userName = userName;
      this.roles = roles;
      this.underwritingLevel = underwritingLevel;
      this.underwritingPriceFrom = underwritingPriceFrom;
      this.underwritingPriceTo = underwritingPriceTo;
   }
}
