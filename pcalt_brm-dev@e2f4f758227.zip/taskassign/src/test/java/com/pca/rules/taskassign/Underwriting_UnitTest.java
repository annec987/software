package com.pca.rules.taskassign;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.KieBase;
import org.kie.api.KieServices;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.kie.api.runtime.ExecutionResults;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

import com.pca.rules.taskassign.ApplicationForm;
import com.pca.rules.taskassign.ControlInfo;
import com.pca.rules.taskassign.PcaTask;
import com.pca.rules.taskassign.ResultTask;
import com.pca.rules.taskassign.UserInfo;

public class Underwriting_UnitTest {

  protected static String KIE_BASE_NAME = "kbase-taskassign";
  protected static String KIE_SESSION_NAME = "defaultKieSession";

  private final static String OUTIDENTIFIER = "outIdentifier";


  protected static KieBase kieBase = null;
  protected static KieServices ks = KieServices.Factory.get();
  protected static KieContainer kieContainer = ks.newKieClasspathContainer();
  protected static KieCommands kieCommands = ks.getCommands();


  @Before
  public void prepareKieBase() {
    if (KIE_BASE_NAME == null || KIE_BASE_NAME.length() == 0) {
      kieBase = kieContainer.getKieBase();
    } else {
      kieBase = kieContainer.getKieBase(KIE_BASE_NAME);
    }
  }


  @Test
  public void testScoreSpecialConditionWithMatch() throws Exception {

    // Prepare PcaTask
    PcaTask task = new PcaTask();
    task.setId(1); // taskId
    task.setName("TEST"); // taskName
    task.setCase_condition_score(1); // 有符合指定條件

    // Prepare ApplicationForm
    ApplicationForm data = new ApplicationForm();
    data.setId(1); // 與taskId相同
    data.setCaseLevel(1); // 設定案件核保等級為決策表範圍內

    // Prepare UserInfo
    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 有符合指定條件的場合，ResultTask的指定條件評分因與PcaTask之值相同
    assertThat("Result of 指定條件評分", resultTask.getScoreSpecialCondition(), is(1L));
    assertThat("Result of 總評分", resultTask.getTotalScore(), is(100000000L));
  }

  @Test
  public void testScoreSpecialConditionWithoutMatch() throws Exception {

    // Prepare PcaTask
    PcaTask task = new PcaTask();
    task.setId(1); // taskId
    task.setName("TEST"); // taskName
    // task.setCase_condition_score(0); // 無符合指定條件，可不設

    // Prepare ApplicationForm
    ApplicationForm data = new ApplicationForm();
    data.setId(1); // 與taskId相同
    data.setCaseLevel(1); // 設定案件核保等級為決策表範圍內

    // Prepare UserInfo
    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 無符合指定條件的場合，ResultTask的指定條件評分因為0
    assertThat("Result of 指定條件評分", resultTask.getScoreSpecialCondition(), is(0L));
    assertThat("Result of 總評分", resultTask.getTotalScore(), is(0L));
  }

  @Test
  public void testScoreCaseImportanceWithMatch() throws Exception {

    PcaTask task = new PcaTask();
    task.setId(1);
    task.setName("TEST");

    ApplicationForm data = new ApplicationForm();
    data.setId(1);
    data.setCaseLevel(1); // 設定案件核保等級為決策表範圍內
    data.setPriority(5); // 案件重要性付值

    // Prepare UserInfo
    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 有符合案件重要性的場合，ResultTask的案件重要性評分因與ScoreCaseImportance.xls之值相同
    assertThat("Result of 案件重要性評分", resultTask.getScoreCaseImportance(), is(20L));
    // 案件重要性評分倍率(1000000)
    assertThat("Result of 總評分", resultTask.getTotalScore(), is(20000000L));
  }

  @Test
  public void testScoreCaseImportanceWithoutMatch() throws Exception {

    PcaTask task = new PcaTask();
    task.setId(1);
    task.setName("TEST");

    ApplicationForm data = new ApplicationForm();
    data.setId(1);
    data.setCaseLevel(1); // 設定案件核保等級為決策表範圍內
    data.setPriority(2); // 案件重要性付值為決策表範圍外

    // Prepare UserInfo
    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 無符合案件重要性的場合，ResultTask的案件重要性評分因為0
    assertThat("Result of 案件重要性評分", resultTask.getScoreCaseImportance(), is(0L));
    // 案件重要性評分倍率(1000000)
    assertThat("Result of 總評分", resultTask.getTotalScore(), is(0L));
  }


  @Test
  public void testScoreUnderwritingWithoutMatch() throws Exception {

    PcaTask task = new PcaTask();
    task.setId(1);
    task.setName("TEST");

    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    ApplicationForm data = new ApplicationForm();
    data.setId(1);
    data.setCaseLevel(6); // 設定案件核保等級為決策表範圍外

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 無符合案件核保等級的場合，不會取得ResultTask
    assertThat("resultTask is Null", resultTask == null);
  }

  @Test
  public void testCancelTaskClaim() throws Exception {

    PcaTask task = new PcaTask();
    task.setId(1);
    task.setName("TEST1");  // 不可認領的Task

    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    ApplicationForm data = new ApplicationForm();
    data.setId(1);
    data.setCaseLevel(1); // 設定案件核保等級為決策表範圍內

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 無符合案件核保等級的場合，不會取得ResultTask
    assertThat("resultTask is Null", resultTask == null);
  }


  @Test
  public void testScoreUnderwritingWithMatch() throws Exception {

    PcaTask task = new PcaTask();
    task.setId(1);
    task.setName("TEST");

    UserInfo taskUser = new UserInfo();
    taskUser.setRoles(Arrays.asList("abc", "4-TEST", "123")); // 設定取件User的Role為等級4

    ApplicationForm data = new ApplicationForm();
    data.setId(1);
    data.setCaseLevel(5); // // 設定案件核保等級為取件User範圍內

    // 執行派工決策表
    ResultTask resultTask = runWithSinglePcaTask_UNDERWRITING(task, data, taskUser);

    // 有符合案件核保等級的場合，ResultTask的核保等級評分因與ScoreUnderwriting.xls之值相同
    assertThat("Result of 核保等級評分", resultTask.getScoreUnderwriting(), is(10L));
    // 核保等級評分倍率(10000)
    assertThat("Result of 總評分", resultTask.getTotalScore(), is(100000L));
  }



  // This test always run as 取件模式 = NB_UNDERWRITING（核保照會）
  protected ResultTask runWithSinglePcaTask_UNDERWRITING(PcaTask task, ApplicationForm data,
      UserInfo taskUser) {
    KieServices ks = KieServices.Factory.get();
    StatelessKieSession kieSession =
        ks.getKieClasspathContainer().newStatelessKieSession(KIE_SESSION_NAME);

    @SuppressWarnings("rawtypes")
    List<Command> cmds = new ArrayList<Command>();
    cmds.add(kieCommands.newInsert(new ControlInfo("NB_UNDERWRITING")));
    cmds.add(kieCommands.newInsert(task));
    cmds.add(kieCommands.newInsert(taskUser));
    cmds.add(kieCommands.newInsert(data));
    cmds.add(kieCommands.newFireAllRules());
    cmds.add(kieCommands.newQuery(OUTIDENTIFIER, "get all result"));
    ExecutionResults results = kieSession.execute(kieCommands.newBatchExecution(cmds));

    // returns the query as a QueryResults instance.
    QueryResults qrs = (QueryResults) results.getValue(OUTIDENTIFIER);

    // Here, we only return 1st result
    if (qrs.iterator().hasNext()) {
      QueryResultsRow result = (QueryResultsRow) qrs.iterator().next();
      ResultTask resultTask = (ResultTask) result.get("$result");
      System.out.println("resultTask: " + resultTask);
      List<String> logs = resultTask.getLogs();
      for (String log : logs) {
        System.out.println("resultTask.logs: " + log);
      }
      return resultTask;
    }
    else{
      return null;
    }
  }
}
