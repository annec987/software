package com.pca.bpms.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@org.kie.api.remote.Remotable
public class PcaTask implements Serializable
{

   /**
    * 
    */
   private static final long serialVersionUID = 3174492112802271529L;

   // Properties same as TaskSummary
   private long id;
   private String name;
   private String subject;
   private String description;
   private String status;
   private String priority;
   private Boolean skipable;
   private String actualOwnerId;
   private String createdById;
   private Date createdOn;
   private Date activationTime;
   private Date expirationTime;
   private long processInstanceId;
   private String processId;
   private long processSessionId;
   private String deploymentId;

   // Properties specific for PCA life
   private String pcaAssignedPeople;
   private List<String> pcaAssingedGroup;
   private String pcaTaskType;

   public PcaTask()
   {
   }

   /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
   @Override
   public String toString()
   {
      return "PcaTask [ id=" + id + ", " + (name != null ? "name=" + name + ", " : "")
            + (subject != null ? "subject=" + subject + ", " : "")
            + (description != null ? "description=" + description + ", " : "")
            + (status != null ? "status=" + status + ", " : "")
            + (priority != null ? "priority=" + priority + ", " : "")
            + (skipable != null ? "skipable=" + skipable + ", " : "")
            + (actualOwnerId != null ? "actualOwnerId=" + actualOwnerId + ", " : "")
            + (createdById != null ? "createdById=" + createdById + ", " : "")
            + (createdOn != null ? "createdOn=" + createdOn + ", " : "")
            + (activationTime != null ? "activationTime=" + activationTime + ", " : "")
            + (expirationTime != null ? "expirationTime=" + expirationTime + ", " : "") + "processInstanceId="
            + processInstanceId + ", " + (processId != null ? "processId=" + processId + ", " : "")
            + "processSessionId=" + processSessionId + ", "
            + (deploymentId != null ? "deploymentId=" + deploymentId + ", " : "")
            + (pcaAssignedPeople != null ? "pcaAssignedPeople=" + pcaAssignedPeople + ", " : "")
            + (pcaAssingedGroup != null ? "pcaAssingedGroup=" + pcaAssingedGroup + ", " : "")
            + (pcaTaskType != null ? "pcaTaskType=" + pcaTaskType + ", " : "") + " ]";
   }

   /**
    * @return the id
    */
   public long getId()
   {
      return id;
   }

   /**
    * @param id the id to set
    */
   public void setId(long id)
   {
      this.id = id;
   }

   /**
    * @return the name
    */
   public String getName()
   {
      return name;
   }

   /**
    * @param name the name to set
    */
   public void setName(String name)
   {
      this.name = name;
   }

   /**
    * @return the subject
    */
   public String getSubject()
   {
      return subject;
   }

   /**
    * @param subject the subject to set
    */
   public void setSubject(String subject)
   {
      this.subject = subject;
   }

   /**
    * @return the description
    */
   public String getDescription()
   {
      return description;
   }

   /**
    * @param description the description to set
    */
   public void setDescription(String description)
   {
      this.description = description;
   }

   /**
    * @return the status
    */
   public String getStatus()
   {
      return status;
   }

   /**
    * @param status the status to set
    */
   public void setStatus(String status)
   {
      this.status = status;
   }

   /**
    * @return the priority
    */
   public String getPriority()
   {
      return priority;
   }

   /**
    * @param priority the priority to set
    */
   public void setPriority(String priority)
   {
      this.priority = priority;
   }

   /**
    * @return the skipable
    */
   public Boolean getSkipable()
   {
      return skipable;
   }

   /**
    * @param skipable the skipable to set
    */
   public void setSkipable(Boolean skipable)
   {
      this.skipable = skipable;
   }

   /**
    * @return the actualOwnerId
    */
   public String getActualOwnerId()
   {
      return actualOwnerId;
   }

   /**
    * @param actualOwnerId the actualOwnerId to set
    */
   public void setActualOwnerId(String actualOwnerId)
   {
      this.actualOwnerId = actualOwnerId;
   }

   /**
    * @return the createdById
    */
   public String getCreatedById()
   {
      return createdById;
   }

   /**
    * @param createdById the createdById to set
    */
   public void setCreatedById(String createdById)
   {
      this.createdById = createdById;
   }

   /**
    * @return the createdOn
    */
   public Date getCreatedOn()
   {
      return createdOn;
   }

   /**
    * @param createdOn the createdOn to set
    */
   public void setCreatedOn(Date createdOn)
   {
      this.createdOn = createdOn;
   }

   /**
    * @return the activationTime
    */
   public Date getActivationTime()
   {
      return activationTime;
   }

   /**
    * @param activationTime the activationTime to set
    */
   public void setActivationTime(Date activationTime)
   {
      this.activationTime = activationTime;
   }

   /**
    * @return the expirationTime
    */
   public Date getExpirationTime()
   {
      return expirationTime;
   }

   /**
    * @param expirationTime the expirationTime to set
    */
   public void setExpirationTime(Date expirationTime)
   {
      this.expirationTime = expirationTime;
   }

   /**
    * @return the processInstanceId
    */
   public long getProcessInstanceId()
   {
      return processInstanceId;
   }

   /**
    * @param processInstanceId the processInstanceId to set
    */
   public void setProcessInstanceId(long processInstanceId)
   {
      this.processInstanceId = processInstanceId;
   }

   /**
    * @return the processId
    */
   public String getProcessId()
   {
      return processId;
   }

   /**
    * @param processId the processId to set
    */
   public void setProcessId(String processId)
   {
      this.processId = processId;
   }

   /**
    * @return the processSessionId
    */
   public long getProcessSessionId()
   {
      return processSessionId;
   }

   /**
    * @param processSessionId the processSessionId to set
    */
   public void setProcessSessionId(long processSessionId)
   {
      this.processSessionId = processSessionId;
   }

   /**
    * @return the deploymentId
    */
   public String getDeploymentId()
   {
      return deploymentId;
   }

   /**
    * @param deploymentId the deploymentId to set
    */
   public void setDeploymentId(String deploymentId)
   {
      this.deploymentId = deploymentId;
   }

   /**
    * @return the pcaAssignedPeople
    */
   public String getPcaAssignedPeople()
   {
      return pcaAssignedPeople;
   }

   /**
    * @param pcaAssignedPeople the pcaAssignedPeople to set
    */
   public void setPcaAssignedPeople(String pcaAssignedPeople)
   {
      this.pcaAssignedPeople = pcaAssignedPeople;
   }

   /**
    * @return the pcaAssingedGroup
    */
   public List<String> getPcaAssingedGroup()
   {
      return pcaAssingedGroup;
   }

   /**
    * @param pcaAssingedGroup the pcaAssingedGroup to set
    */
   public void setPcaAssingedGroup(List<String> pcaAssingedGroup)
   {
      this.pcaAssingedGroup = pcaAssingedGroup;
   }

   /**
    * @return the pcaTaskType
    */
   public String getPcaTaskType()
   {
      return pcaTaskType;
   }

   /**
    * @param pcaTaskType the pcaTaskType to set
    */
   public void setPcaTaskType(String pcaTaskType)
   {
      this.pcaTaskType = pcaTaskType;
   }

   public PcaTask(long id, java.lang.String name, java.lang.String subject,
         java.lang.String description, java.lang.String status,
         java.lang.String priority, java.lang.Boolean skipable,
         java.lang.String actualOwnerId, java.lang.String createdById,
         java.util.Date createdOn, java.util.Date activationTime,
         java.util.Date expirationTime, long processInstanceId,
         java.lang.String processId, long processSessionId,
         java.lang.String deploymentId, java.lang.String pcaAssignedPeople,
         java.util.List<java.lang.String> pcaAssingedGroup,
         java.lang.String pcaTaskType)
   {
      this.id = id;
      this.name = name;
      this.subject = subject;
      this.description = description;
      this.status = status;
      this.priority = priority;
      this.skipable = skipable;
      this.actualOwnerId = actualOwnerId;
      this.createdById = createdById;
      this.createdOn = createdOn;
      this.activationTime = activationTime;
      this.expirationTime = expirationTime;
      this.processInstanceId = processInstanceId;
      this.processId = processId;
      this.processSessionId = processSessionId;
      this.deploymentId = deploymentId;
      this.pcaAssignedPeople = pcaAssignedPeople;
      this.pcaAssingedGroup = pcaAssingedGroup;
      this.pcaTaskType = pcaTaskType;
   }

}
