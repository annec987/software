package com.pca.bpms.model;

import java.io.Serializable;

@org.kie.api.remote.Remotable
public class ControlInfo implements Serializable
{

   /**
    * 
    */
   private static final long serialVersionUID = -734703388840206202L;
   private String checkoutMode;

   public ControlInfo()
   {
   }

   @Override
   public String toString()
   {
      return "ControlInfo [" + (checkoutMode != null ? "checkoutMode=" + checkoutMode : "") + "]";
   }

   /**
    * @return the checkoutMode
    */
   public String getCheckoutMode()
   {
      return checkoutMode;
   }

   /**
    * @param checkoutMode the checkoutMode to set
    */
   public void setCheckoutMode(String checkoutMode)
   {
      this.checkoutMode = checkoutMode;
   }

   public ControlInfo(java.lang.String checkoutMode)
   {
      this.checkoutMode = checkoutMode;
   }

}
